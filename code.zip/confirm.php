<?php
session_start();
require "common.php";
$name=$_POST['data'];
$amount=$_POST['amount'];
$payment_details_query= "insert into transactions(name,amount) values ('$name', '$amount')";
$payment_details_submit= mysqli_query($con, $payment_details_query) or die(mysqli_error($con));
if($payment_details_query){
    $_SESSION['alert']="hi";
 header("Location:transaction.php");
}
else{
die(mysqli_error($payment_details_query));
}

?>