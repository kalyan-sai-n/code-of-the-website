<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title></title>
    <link rel="stylesheet" href="style.css">
    <style>
        .btn{
    position: absolute;
    top:5%;
    left:80%;
    border:2px solid orangered;
    padding:10px;
    margin:10px;
    background-color: black;
    border-radius: 20px;
    color:white;
    text-decoration:none;
 
}
.btn:hover{
    color:black;
    background-color:yellow;
}
    </style>
</head>
<body>
    <div class="about-section">
        <div class="inner-container">
            <h1>About Us</h1>
            <p class="text">
              This pasge is developed by N.Kalyan sai, as a part of internship in Spark Foundation.to contact me use the below given email.
            </p>
            <div class="skills">
                <span>email:</span>
                <span>kalyangoudjnvc@gmail.com</span>
            </div>
        </div>
    </div>
  
    <a href="../index.php" class="btn">back</a>   
</body>
</html>