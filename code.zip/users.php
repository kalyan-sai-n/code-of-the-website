<?php require "common.php";
$result=mysqli_query($con,"SELECT* from user_details ORDER by id ASC");
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <title>users</title>

</head>

<style>
    body {
        padding: 0px;
        margin: 0;
        font-family: Verdana, Geneva, Tahoma, sans-serif;
        background-image:url(img.jpeg); 
        background-repeat:no-repeat;
        background-size:cover;
        width:100%;
        height:100%;
    }
   .elements{
    display: inline-block;
    padding:7px;
    background-color: transparent;
    text-align:center;
    float:right;}

    table, th, td {
    border:2px solid white;
    text-align:center;
    border-collapse: collapse;
    margin-top: 20%;
    padding:7px;
    color: white;
    background-color: transparent;
}
tr {
    border-collapse: collapse;
    transition: all .2s ease-in;
    cursor: pointer;
}


tr:hover {
    background-color:black;
    transform: scale(1.02);
    box-shadow: 2px 2px 12px orange, -1px -1px 8px yellow;
}
@media only screen and (max-width: 768px) {
    table {
        width: 90%;
    }
    body {
        width: 90%;
    }
}

    
    #header {
        background-color: #16a085;
        color: #fff;
    }
    
    h1 {
        font-weight: 600;
        text-align: center;
        background-color: #16a085;
        color: #fff;
        padding: 10px 0px;
    }
    
    table{
    position:absolute;
    top:-20%;
    margin-left: 20%;
    width:60%;
   
}
.btn{
    position: absolute;
    top:20%;
    left:90%;
    border:2px solid orangered;
    ]
    margin:10px;
    background-color: black;
    border-radius: 20px;
    color:white;
    text-decoration:none;
}
.btn:hover{
    color:black;
    background-color:white;
   

}
.btn1{
    position: absolute;
    left:83%;
}
.btn2{
    background-color:blue;
    color:black;
    border:2px solid black;
    border-radius:20px;
    text-decoration:none;
}
.btn2:hover{
    background-color:yellow;
    color:blue;
}
.link{
    color:black;
    text-decoration:none;
}
.link:hover{
    text-decoration:none;
}
footer{
    margin-top:300x;
    background-color: black;
    height: 50px;
    width: 100%;
    position: absolute;
    bottom: -3%;
    color: wheat;
}
.para{
    padding-top:1.5%;
}
</style>

<body>

    <h1>Users Details</h1>
    <hr>


    <table>
    <tr id="header">
            <th>S.NO</th>
            <th>Name</th>
            <th>Balance</th>
            <th>Date</th>
            <th>Transist</th>
        </tr>
        <?php 
        while($res=mysqli_fetch_array($result)){
         echo '<tr>';
         echo '<td>'.$res['id'].'</td>';
         echo '<td>'.$res['name'].'</td>';
         echo '<td>'.$res['account_balance'].'</td>';
         echo '<td>'.$res['email'].'</td>';
         echo '<td><button class="btn2"><a class="link" href="main.php">transfer</a></button></td>';
         echo '</tr>';
        }
        ?>  
    </table>
    <div class="continer-fluid">
             <div class="elements">
             <a href="index.php" class="btn btn1">HOME</a>
             <a href="main.php" class="btn">TRANSFER</a>   
         </div>
<footer>
            <div class="container">
                <center>
                    <p class="para">Copyright © Sparks Foundations. All Rights Reserved” ​ and ​ “Contact Us: +91 90000 00000 developed by:N.KALYAN SAI</p>
                </center>
            </div>
        </footer>
</body>

</html>