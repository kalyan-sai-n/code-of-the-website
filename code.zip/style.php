html,body{
    padding:0;
    margin:0;
    background-image: url(img.jpeg);
    background-size: cover;
    background-position: center;
    background-repeat: no-repeat;
    width:100%;
    height:95vh;
    position: relative;
    margin-top:-10px;

}
.navbar{
    text-decoration: none;
    text-lign:center;
    
}
.elements{
    display: inline-block;
    padding:7px;
    background-color: transparent;
    text-align:center;
    float:right;
}

.btn{
    border:2px solid orangered;
    paddin:10px;
    margin:10px;
    background-color: black;
    border-radius: 20px;
    color:white;
}
.btn:hover{
    color:black;
    background-color:white;
   
}

h1{
    text-align:center;
    color:red;
    font-size:80px;
    letter-spacing: 4px;
    animation:text 3s 1;
    margin-bottom: -0px;
    font-family: 'Mate SC', serif;
}
.row{
top:50%;
margin-top:25%;
}



@keyframes text{
    0%{
        color:gold;
        margin-bottom:-40px;
    }
    30%{
        letter-spacing:25px;
        margin-bottom:-40px;
    }
    85%{
        letter-spacing:8px;
        margin-bottom:-40px;
    }
}

