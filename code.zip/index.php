<!DOCTYPE html>
<html>
    <head>
        <title>HOMEPAGE</title>
        <link rel="preconnect" href="https://fonts.gstatic.com">
        <link href="https://fonts.googleapis.com/css2?family=Mate+SC&display=swap" rel="stylesheet"> 
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
          <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
          <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
          <link rel="preconnect" href="https://fonts.gstatic.com">
         <link href="https://fonts.googleapis.com/css2?family=Stint+Ultra+Condensed&display=swap" rel="stylesheet"> 
                <link rel="stylesheet" type="text/css" href="style/style.css">
                <style>
                    .navbar{
    position: absolute;
    top:0.1%;
    margin-top:-0.5%;
    width: 100%;
}
                </style>
                
    </head>
    <body>
        <nav class="navbar navbar-inverse">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>    
                    <a href="#" class="navbar-brand">Sparks Foundation</a>
                </div>
                <div class="collapse navbar-collapse" id="myNavbar">
              <ul class="nav navbar-nav navbar-right">
                  <li><a href="About/about.php"> ABOUT</a></li>
                  <li><a href="main.php">  TRANSFER</a></li>
                  <li><a href="transaction.php">TRANSCATIONS</a></li>
              </ul> 
           </div>
            </div> 
        </nav> 
        <div class="background">
            <h1 class="text-1">Welcome to the</h1><h1 class="text-2">Sparks Foundation bank</h1>
            <img src="532.png" class="logo">
        </div>
        <div class="description">
            <img src="user.png" alt="users" class="users">
            <button class="button"><a href="users.php" class="link">Users</a></button>
            <img src="index.jpg" alt="transfer" class="transfer">
            <button class="button-2" ><a class="link" href="main.php">Transfer</a></button>
            <img src="index.png" alt="transfer" class="history">
            <button class="button-3"><a href="transaction.php" class="link">Transactions</a></button>
        </div>
        <footer>
            <div class="container">
                <center>
                    <p class="para">Copyright © Sparks Foundations. All Rights Reserved” ​ and ​ “Contact Us: +91 90000 00000 developed by:N.KALYAN SAI</p>
                </center>
            </div>
        </footer>
    </body>
</html>