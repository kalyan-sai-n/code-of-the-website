<?php
$con= mysqli_connect ("localhost", "id16994629_root", "Kalyansai@123", "id16994629_payment") or die(mysqli_error($con));
?>
