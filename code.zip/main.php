<?php require "common.php";?>
<?php
session_start();
$result1=mysqli_query($con,"SELECT* from user_details ORDER by id DESC");
  ?>
 
<!DOCTYPE html>
<html>
    <head>
        <title>payment</title>
        <meta charset="UTF-8">
         <link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Mate+SC&display=swap" rel="stylesheet"> 
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
   <link rel="stylesheet" type="text/css" href="style.css">
   <script>
    function call(){
      alert("transaction successfull");
    }
  </script>
  <style>
    footer{
    margin-top:300x;
    background-color: black;
    height: 50px;
    width: 100%;
    position: absolute;
    bottom: -5.4%;
    color: wheat;
}
.para{
    padding-top:1.5%;
}
table,td,th{
    border:2px solid white;
    text-align:center;
     color:black;
}
table{
  position:absolute;
  top:30%;
  left:10%;
  width:80%;
  text-align:center;
  height:10%;
  background-color:#99d6ff;
}
tr{
    border-collapse: collapse;
    transition: all .2s ease-in;
    cursor: pointer;
    
}
tr:hover {
    background-color:white;
    transform: scale(1.02);
    box-shadow: 2px 2px 12px orange, -1px -1px 8px yellow;
    
}
  </style>
    </head>
    <body>
        <div class="continer-fluid">
             <div class="elements">
             <a href="index.php" class="btn">HOME</a>
             <a href="main.php" class="btn">PAYMENT</a> 
             <a href="transaction.php" class="btn">TRANSACTION HISTORY</a>  
         </div>
         </div>
        <table>
          <tr>
            <th>Id</th>
            <th>Sender</th>
            <th>Emial</th>
            <th>Balance</th>
          </tr>
          <tr>
            <td>2</td>
            <td>kalyan</td>
            <td>kalyansai397@gmail.com</td>
            <td>1000000</td>
          </tr>
        </table>
        <h1>Transfer money</h1>
        <div class="container">
            <div class="row">
                <div class="col-lg-4 col-lg-offset-4 col-md-6 col-md-offset-3">
                
                <form method="POST" action="confirm.php">
 
                             <div class="form-group">
                           <select name="data" class="form-control">
	<?php 
	       while($row1 = mysqli_fetch_array($result1)):;?>
            <option class="form-control" ><?php echo $row1['name'];?></option>
          <?php endwhile; ?>
           
            </select>
                             </div>
                             <div class="form-group">
                              <input class="form-control" placeholder="Enter amount" name="amount" required>
                             </div>
                    <button type="submit" name="submit" class="btn btn-success button" onclick="call()">Submit</button>
                </form>
                </div>
        </div>
           
            </div>   
            <footer>
            <div class="container">
                <center>
                    <p class="para">Copyright © Sparks Foundations. All Rights Reserved” ​ and ​ “Contact Us: +91 90000 00000 developed by:N.KALYAN SAI</p>
                </center>
            </div>
        </footer>     
      </body>
</html>